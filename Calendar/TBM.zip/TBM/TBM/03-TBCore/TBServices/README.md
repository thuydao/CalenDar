# TBServices

Copyright: Thuy Dao
===================================

- Auto check & manage network
- AFNetWorking 2.5: connect api

===================================
Tutorial:
===================================

add TDTDReachability: [TDReachability shared]; into [appDelegate didFinishLaunchingWithOptions]