//
//  WBRedGradientView.h
//  GradientView
//
//  Created by Tito Ciuro on 6/3/12.
//  Copyright (c) 2012 Webbo, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WBRedGradientView : UIView

@end
