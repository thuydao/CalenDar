//
//  TBAlert.h
//  TBM
//
//  Created by thuydd on 1/30/15.
//  Copyright (c) 2015 QsoftVietNam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TBBaseObject.h"

@interface TBAlert : TBBaseObject

@end
