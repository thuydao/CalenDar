//
//  DetailVideoViewController.h
//  TBM
//
//  Created by Thuỷ Đào  on 3/25/15.
//  Copyright (c) 2015 QsoftVietNam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface DetailVideoViewController : TBBaseViewController < UITableViewDataSource, UITableViewDelegate>
{
}
@property (nonatomic, weak) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSString *videoID;
@property (nonatomic, strong) NSURL *URLPlay;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) MPMoviePlayerViewController *moviePlayer;
@property (nonatomic, strong) NSMutableArray *dataSource;


- (void)callAPIGetRelateVideo;

@end
