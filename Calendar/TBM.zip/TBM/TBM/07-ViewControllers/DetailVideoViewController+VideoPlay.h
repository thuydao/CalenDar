//
//  DetailVideoViewController+VideoPlay.h
//  TBM
//
//  Created by Thuỷ Đào  on 3/25/15.
//  Copyright (c) 2015 QsoftVietNam. All rights reserved.
//

#import "DetailVideoViewController.h"

@interface DetailVideoViewController (VideoPlay)


- (void)reloadVideo;
- (void)drawHeaderView;
- (void)reloadVideo;

@end
