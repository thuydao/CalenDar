//
//  DetailVideoViewController.m
//  TBM
//
//  Created by Thuỷ Đào  on 3/25/15.
//  Copyright (c) 2015 QsoftVietNam. All rights reserved.
//

#import "DetailVideoViewController.h"
#import "DetailVideoViewController+VideoPlay.h"

@interface DetailVideoViewController ()

@end

@implementation DetailVideoViewController

#pragma mark - LifeCicycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.videoID = @"oBQEPENUwYM";
    self.dataSource = [NSMutableArray new];
    
    [self callAPIGetRelateVideo];
    
    [self drawHeaderView];
    [self reloadVideo];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc
{
    
}

#pragma mark - Setter & Getter

#pragma mark - IBaction

#pragma mark - funtion

#pragma mark - TableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = nil;
    cell = [tableView dequeueReusableCellWithIdentifier:@"youtubeCell"];
    if (!cell)
    {
        NSLog(@"cell == nil, need to recheck storyboard");
        cell = [UITableViewCell new];
    }
    
    NSDictionary *dict = [self.dataSource objectAtIndex:indexPath.row];
    ((UILabel *)[cell viewWithTag:2]).text = [[dict tb_dictionaryForKey:@"snippet"] tb_stringForKey:@"title"];
    
    ((UILabel *)[cell viewWithTag:3]).text = [[dict tb_dictionaryForKey:@"snippet"] tb_stringForKey:@"channelTitle"];
    
    NSString *urlString = [[[[dict tb_dictionaryForKey:@"snippet"] tb_dictionaryForKey:@"thumbnails"] tb_dictionaryForKey:@"default"] tb_stringForKey:@"url"];
    
    [((UIImageView *)[cell viewWithTag:1]) sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:nil];
    ((UIImageView *)[cell viewWithTag:1]).contentMode = UIViewContentModeScaleAspectFit;
    
    return cell;
}

#pragma mark - Delegate




@end
