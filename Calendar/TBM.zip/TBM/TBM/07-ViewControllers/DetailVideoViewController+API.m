//
//  DetailVideoViewController+API.m
//  TBM
//
//  Created by Thuỷ Đào  on 3/25/15.
//  Copyright (c) 2015 QsoftVietNam. All rights reserved.
//

#import "DetailVideoViewController+API.h"

@implementation DetailVideoViewController (API)

- (void)callAPIGetRelateVideo
{
    [TBServices callAPIWithUrl:[NSString stringWithFormat:@"&maxResults=20&relatedToVideoId=%@&type=video",self.videoID] withTypeAPI:GET withParams:nil completed:^(id result, NSError *error) {
        if (result) {
            NSLog(@"result: %@",result);
            self.dataSource = [[NSMutableArray alloc] initWithArray:[result tb_arrayForKey:@"items"]];
            [self.tableView reloadData];
        }
    }];
}

@end
