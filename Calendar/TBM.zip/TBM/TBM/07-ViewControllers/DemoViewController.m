//
//  DemoViewController.m
//  MFSideMenuDemoStoryboard
//
//  Created by Michael Frederick on 4/9/13.
//  Copyright (c) 2013 Michael Frederick. All rights reserved.
//

#import "DemoViewController.h"
#import "MFSideMenu.h"
#import <MediaPlayer/MediaPlayer.h>
#import "HCYoutubeParser.h"

@interface DemoViewController ()
{
    NSURL *urlToLoad;
}

@end

@implementation DemoViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self test];
}


- (IBAction)showLeftMenuPressed:(id)sender {
    [self.menuContainerViewController toggleLeftSideMenuCompletion:nil];
}

- (IBAction)showRightMenuPressed:(id)sender {
    [self.menuContainerViewController toggleRightSideMenuCompletion:nil];
}


- (void)test
{
    NSURL *url = [NSURL URLWithString:@"https://www.youtube.com/watch?v=TWwwSYJ0VVI"];
    [HCYoutubeParser thumbnailForYoutubeURL:url thumbnailSize:YouTubeThumbnailDefaultHighQuality completeBlock:^(UIImage *image, NSError *error) {
        
        if (!error) {
            
            //get success thumbnail
            
            [HCYoutubeParser h264videosWithYoutubeURL:url completeBlock:^(NSDictionary *videoDictionary, NSError *error) {
                
                NSDictionary *qualities = videoDictionary;
                
                NSString *URLString = nil;
                if ([qualities objectForKey:@"small"] != nil) {
                    URLString = [qualities objectForKey:@"small"];
                }
                else if ([qualities objectForKey:@"live"] != nil) {
                    URLString = [qualities objectForKey:@"live"];
                }
                else {
                    [[[UIAlertView alloc] initWithTitle:@"Error" message:@"Couldn't find youtube video" delegate:nil cancelButtonTitle:@"Close" otherButtonTitles: nil] show];
                    return;
                }
                [self playVideo:[NSURL URLWithString:URLString]];
            }];
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alert show];
        }
    }];
}

- (void)playVideo:(NSURL *)url
{
    
    if (url) {
        
        MPMoviePlayerViewController *moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
        moviePlayer.view.frame = CGRectMake(0, 100, self.view.frame.size.width, self.view.frame.size.width/1.775);
        moviePlayer.moviePlayer.fullscreen = NO;
        moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
        [self.view addSubview:moviePlayer.view];
    }
    
}


@end
