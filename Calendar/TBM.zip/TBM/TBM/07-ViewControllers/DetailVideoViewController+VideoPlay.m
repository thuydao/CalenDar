//
//  DetailVideoViewController+VideoPlay.m
//  TBM
//
//  Created by Thuỷ Đào  on 3/25/15.
//  Copyright (c) 2015 QsoftVietNam. All rights reserved.
//


// as header tableview
#import "DetailVideoViewController+VideoPlay.h"
#import "HCYoutubeParser.h"

@implementation DetailVideoViewController (VideoPlay)

- (void)drawHeaderView
{
    NSLog(@"sth...");
    
    CGFloat y = self.view.frame.size.width/1.775;
    CGFloat height = self.view.frame.size.height - y;
    
    CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, y);
    
    
    if (!self.headerView)
    {
        self.headerView = [[UIView alloc] init];
        self.headerView.frame = frame;
    }
    
    
    //reszie tableview
    [self.view addSubview:self.headerView];
    self.tableView.frame = CGRectMake(0, y, self.view.frame.size.width, height);
}

- (void)reloadVideo
{
    //get thumbnail for video
    
    NSString *urlString = [NSString stringWithFormat:@"https://www.youtube.com/watch?v=%@",self.videoID];
    
    self.URLPlay = nil;
    
    __weak __typeof(self) weakSelf = self;
    
    [HCYoutubeParser thumbnailForYoutubeURL:[NSURL URLWithString:urlString] thumbnailSize:YouTubeThumbnailDefaultHighQuality completeBlock:^(UIImage *image, NSError *error) {
        
        if (!error) {
            
            //get success thumbnail
            NSLog(@"get success thubnail");
            [HCYoutubeParser h264videosWithYoutubeURL:[NSURL URLWithString:urlString] completeBlock:^(NSDictionary *videoDictionary, NSError *error) {
                
                NSDictionary *qualities = videoDictionary;
                
                NSString *URLString = nil;
                if ([qualities objectForKey:@"small"] != nil) {
                    URLString = [qualities objectForKey:@"small"];
                }
                else if ([qualities objectForKey:@"live"] != nil) {
                    URLString = [qualities objectForKey:@"live"];
                }
                else {
                    [[[UIAlertView alloc] initWithTitle:@"Error" message:@"Couldn't find youtube video" delegate:nil cancelButtonTitle:@"Close" otherButtonTitles: nil] show];
                    return;
                }
                weakSelf.URLPlay = [NSURL URLWithString:URLString];
                [weakSelf playvideo];
                NSLog(@"success..");
            }];
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
            [alert show];
        }
    }];
}

- (void)playvideo
{
    if (self.URLPlay)
    {
        CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.width/1.775);
        MPMoviePlayerViewController *moviePlayer = [[MPMoviePlayerViewController alloc] initWithContentURL:self.URLPlay];
        moviePlayer.view.frame = frame;
        moviePlayer.moviePlayer.fullscreen = NO;
        moviePlayer.moviePlayer.controlStyle = MPMovieControlStyleEmbedded;
        [self.headerView addSubview:moviePlayer.view];
    }
}

@end
