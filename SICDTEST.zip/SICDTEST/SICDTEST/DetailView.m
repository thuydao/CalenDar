//
//  DetailView.m
//  Test
//
//  Created by thuydd on 3/28/15.
//  Copyright (c) 2015 TB. All rights reserved.
//

#import "DetailView.h"

@implementation DetailView


- (void)addPan {
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    pan.delegate = (id)self;
    [self addGestureRecognizer:pan];
}

#pragma mark- Pan Gesture Selector Action

- (void)panAction:(UIPanGestureRecognizer *)recognizer {
    CGFloat y = [recognizer locationInView:self].y;
    
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        self.direction = UIPanGestureRecognizerDirectionUndefined;
        //storing direction
        CGPoint velocity = [recognizer velocityInView:recognizer.view];
        [self detectPanDirection:velocity];
        
        //Snag the Y position of the touch when panning begins
        self.touchPositionInHeaderY = [recognizer locationInView:self.videoView].y;
        self.touchPositionInHeaderX = [recognizer locationInView:self.videoView].x;
        if (self.direction == UIPanGestureRecognizerDirectionDown) {
            NSLog(@"downn");
        }
    }
    else if (recognizer.state == UIGestureRecognizerStateChanged) {
        NSLog(@"change");
        if (self.direction == UIPanGestureRecognizerDirectionDown || self.direction == UIPanGestureRecognizerDirectionUp) {
            CGFloat trueOffset = y - self.touchPositionInHeaderY;
            CGFloat xOffset = (y - self.touchPositionInHeaderY) * 0.35;
            [self adjustViewOnVerticalPan:trueOffset:xOffset recognizer:recognizer];
        }
        else if (self.direction == UIPanGestureRecognizerDirectionRight || self.direction == UIPanGestureRecognizerDirectionLeft) {
            [self adjustViewOnHorizontalPan:recognizer];
        }
    }
    else if (recognizer.state == UIGestureRecognizerStateEnded) {
        NSLog(@"end");
        if (self.direction == UIPanGestureRecognizerDirectionDown || self.direction == UIPanGestureRecognizerDirectionUp) {
            if (recognizer.view.frame.origin.y < 0) {
                //                [self expandViewOnPan];
                
                [recognizer setTranslation:CGPointZero inView:recognizer.view];
                
                return;
            }
            else if (recognizer.view.frame.origin.y > (self.initialFirstViewFrame.size.width / 2)) {
                //                [self minimizeViewOnPan];
                [recognizer setTranslation:CGPointZero inView:recognizer.view];
                return;
            }
            else if (recognizer.view.frame.origin.y < (self.initialFirstViewFrame.size.width / 2)) {
                //                [self expandViewOnPan];
                [recognizer setTranslation:CGPointZero inView:recognizer.view];
                return;
            }
        }
        
        else if (self.direction == UIPanGestureRecognizerDirectionLeft) {
            /*
             if (self.viewTable.alpha <= 0) {
             if (recognizer.view.frame.origin.x < 0) {
             [self.view removeFromSuperview];
             [self removeView];
             [self.delegate removeController];
             }
             else {
             [self animateViewToRight:recognizer];
             }
             }
             */
        }
        
        else if (self.direction == UIPanGestureRecognizerDirectionRight) {
            /*
             if (self.viewTable.alpha <= 0) {
             if (recognizer.view.frame.origin.x > self.initialFirstViewFrame.size.width - 50) {
             [self.view removeFromSuperview];
             [self removeView];
             [self.delegate removeController];
             }
             else {
             [self animateViewToLeft:recognizer];
             }
             }
             */
        }
    }
}

- (void)adjustViewOnHorizontalPan:(UIPanGestureRecognizer *)recognizer {
    CGFloat x = [recognizer locationInView:self].x;
    if (self.direction == UIPanGestureRecognizerDirectionLeft) {
        if (self.videoView.alpha <= 0) {
            NSLog(@"UIPanGestureRecognizerDirectionLeft alpha <= 0");
            //                NSLog(@"recognizer x=%f", recognizer.view.frame.origin.x);
            //                CGPoint velocity = [recognizer velocityInView:recognizer.view];
            //
            //                BOOL isVerticalGesture = fabs(velocity.y) > fabs(velocity.x);
            //
            //
            //
            //                CGPoint translation = [recognizer translationInView:recognizer.view];
            //
            //                recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
            //                                                     recognizer.view.center.y);
            //
            //
            //                if (!isVerticalGesture) {
            //                    CGFloat percentage = (x / self.initialFirstViewFrame.size.width);
            //
            //                    recognizer.view.alpha = percentage;
            //                }
            //
            //                [recognizer setTranslation:CGPointZero inView:recognizer.view];
        }
    }
    else if (self.direction == UIPanGestureRecognizerDirectionRight) {
        if (self.videoView.alpha <= 0) {
            NSLog(@"UIPanGestureRecognizerDirectionRight alpha <= 0");
            //                NSLog(@"recognizer x=%f", recognizer.view.frame.origin.x);
            //                CGPoint velocity = [recognizer velocityInView:recognizer.view];
            //
            //                BOOL isVerticalGesture = fabs(velocity.y) > fabs(velocity.x);
            //
            //
            //
            //                CGPoint translation = [recognizer translationInView:recognizer.view];
            //
            //                recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
            //                                                     recognizer.view.center.y);
            //
            //
            //                if (!isVerticalGesture) {
            //                    if (velocity.x > 0) {
            //                        CGFloat percentage = (x / self.initialFirstViewFrame.size.width);
            //                        recognizer.view.alpha = 1.0 - percentage;
            //                    }
            //                    else {
            //                        CGFloat percentage = (x / self.initialFirstViewFrame.size.width);
            //                        recognizer.view.alpha = percentage;
            //                    }
            //                }
            //
            //                [recognizer setTranslation:CGPointZero inView:recognizer.view];
        }
    }
}

- (void)adjustViewOnVerticalPan:(CGFloat)trueOffset:(CGFloat)xOffset recognizer:(UIPanGestureRecognizer *)recognizer {
    CGFloat y = [recognizer locationInView:self].y;
    
    if (trueOffset >= restrictTrueOffset + 60 || xOffset >= restrictOffset + 60) {
        CGFloat trueOffset = self.initialFirstViewFrame.size.height - 100;
        CGFloat xOffset = self.initialFirstViewFrame.size.width - 160;
        
        NSLog(@"down down");
        
        //            [UIView animateWithDuration:0.05
        //                                  delay:0.0
        //                                options:UIViewAnimationOptionCurveEaseInOut
        //                             animations: ^{
        //                                 self.viewTable.frame = menuFrame;
        //                                 self.viewYouTube.frame = viewFrame;
        //                                 player.view.frame = CGRectMake(player.view.frame.origin.x,  player.view.frame.origin.x, viewFrame.size.width, viewFrame.size.height);
        //                                 self.viewTable.alpha = 0;
        //                             }
        //                             completion: ^(BOOL finished) {
        //                                 minimizedYouTubeFrame = self.viewYouTube.frame;
        //
        //                                 isExpandedMode = FALSE;
        //                             }];
        //            [recognizer setTranslation:CGPointZero inView:recognizer.view];
    }
    else {
        //            //Use this offset to adjust the position of your view accordingly
        //            menuFrame.origin.y = trueOffset;
        //            menuFrame.origin.x = xOffset;
        //            menuFrame.size.width = self.initialFirstViewFrame.size.width - xOffset;
        //            viewFrame.size.width = self.view.bounds.size.width - xOffset;
        //            viewFrame.size.height = 200 - xOffset * 0.5;
        //            viewFrame.origin.y = trueOffset;
        //            viewFrame.origin.x = xOffset;
        //            float restrictY = self.initialFirstViewFrame.size.height - self.viewYouTube.frame.size.height - 10;
        
        
        NSLog(@"up up");
    }
}

- (void)detectPanDirection:(CGPoint)velocity {
    BOOL isVerticalGesture = fabs(velocity.y) > fabs(velocity.x);
    
    if (isVerticalGesture) {
        if (velocity.y > 0) {
            self.direction = UIPanGestureRecognizerDirectionDown;
        }
        else {
            self.direction = UIPanGestureRecognizerDirectionUp;
        }
    }
    else {
        if (velocity.x > 0) {
            self.direction = UIPanGestureRecognizerDirectionRight;
        }
        else {
            self.direction = UIPanGestureRecognizerDirectionLeft;
        }
    }
}

@end
