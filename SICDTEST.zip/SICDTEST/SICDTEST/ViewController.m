//
//  ViewController.m
//  SICDTEST
//
//  Created by thuydd on 3/28/15.
//  Copyright (c) 2015 TB. All rights reserved.
//

#import "ViewController.h"
#import "DetailView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self startSecondView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)startSecondView {
    DetailView *myView = [[[NSBundle mainBundle] loadNibNamed:@"DetatilView" owner:self options:nil] objectAtIndex:0];
    
    [myView addPan];
    
    [self.view addSubview:myView];
}

@end
