//
//  DetailView.h
//  Test
//
//  Created by thuydd on 3/28/15.
//  Copyright (c) 2015 TB. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuartzCore/CALayer.h"

typedef NS_ENUM (NSUInteger, UIPanGestureRecognizerDirection) {
    UIPanGestureRecognizerDirectionUndefined,
    UIPanGestureRecognizerDirectionUp,
    UIPanGestureRecognizerDirectionDown,
    UIPanGestureRecognizerDirectionLeft,
    UIPanGestureRecognizerDirectionRight
};

@interface DetailView : UIView
{
    //local restriction Offset--- for checking out of bound
    float restrictOffset, restrictTrueOffset, restictYaxis;
}

@property (nonatomic, retain) UIView *videoView;

//detecting Pan gesture Direction
@property (nonatomic, assign) UIPanGestureRecognizerDirection direction;
//local touch location
@property (nonatomic, assign) CGFloat touchPositionInHeaderY;
@property (nonatomic, assign) CGFloat touchPositionInHeaderX;

@property (nonatomic) CGRect initialFirstViewFrame;

- (void)addPan;

@end
