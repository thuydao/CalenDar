//
//  AppDelegate.h
//  SICDTEST
//
//  Created by thuydd on 3/28/15.
//  Copyright (c) 2015 TB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

