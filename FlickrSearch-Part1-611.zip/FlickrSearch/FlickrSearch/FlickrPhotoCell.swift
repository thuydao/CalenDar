//
//  FlickrPhotoCell.swift
//  FlickrSearch
//
//  Created by Michael Oliver on 9/14/14.
//  Copyright (c) 2014 Razeware. All rights reserved.
//

import UIKit

class FlickrPhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
