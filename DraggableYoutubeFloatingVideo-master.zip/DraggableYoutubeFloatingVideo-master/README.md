# DraggableYoutubeFloatingVideo

DraggableYoutubeFloatingVideo allows you to play videos on a floating mini window at the bottom of your screen from sites like YouTube, Vimeo & Facebook or custom video url , yes you have to specify URL for that. 

Usage
-----
Initialize from a storyboard id  programmatically. Set the video URL , then you're pretty much good to go! Check out the demo app to see how it can be used.


How it works
------------
This demo app will animate the view just like Youtube mobile app, while tapping on video a UIView pops up from right corner of the screen and the view can be dragged to  right corner through Pan Gesture and more features are there as Youtube iOS app 

Screenshot
------------

 ![Output sample](https://github.com/vizllx/DraggableYoutubeFloatingVideo/raw/master/Screenshot.gif)
